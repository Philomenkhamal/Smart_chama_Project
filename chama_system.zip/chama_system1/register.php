<?php
// Bypass ngrok browser warning
@header('ngrok-skip-browser-warning: true');
/**
 * CHAMA Financial Management System
 * Registration Handler
 * POST /register.php
 */

require_once __DIR__ . '/includes/functions.php';
if (!dbIsReady()) { header('Location: ' . APP_URL . '/setup.php'); exit; }

startSession();

// Redirect already-logged-in users
if (isLoggedIn()) {
    $role = $_SESSION['user_role'] ?? 'member';
    redirect(APP_URL . ($role === 'admin' ? '/admin/dashboard.php' : '/member/dashboard.php'));
}

$errors   = [];
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF check
    if (!verifyCsrf($_POST['csrf_token'] ?? '')) {
        $errors[] = t('err_invalid_csrf');
    } else {

        // Collect & sanitize
        $formData = [
            'full_name'        => cleanInput($_POST['full_name']        ?? ''),
            'email'            => strtolower(trim($_POST['email']     ?? '')),
            'phone'            => cleanInput($_POST['phone']            ?? ''),
            'national_id'      => cleanInput($_POST['national_id']      ?? ''),
            'occupation'       => cleanInput($_POST['occupation']       ?? ''),
            'address'          => cleanInput($_POST['address']          ?? ''),
            'next_of_kin'      => cleanInput($_POST['next_of_kin']      ?? ''),
            'next_of_kin_phone'=> cleanInput($_POST['next_of_kin_phone']?? ''),
        ];
        $password  = $_POST['password']         ?? '';
        $password2 = $_POST['password_confirm'] ?? '';

        // Validation
        if (strlen($formData['full_name']) < 3)
            $errors[] = t('err_fullname_short');

        if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL))
            $errors[] = t('err_invalid_email2');

        if (!preg_match('/^[0-9]{10,13}$/', $formData['phone']))
            $errors[] = t('err_phone_format');

        // national_id is optional - skip length validation

        if (strlen($password) < 8)
            $errors[] = t('err_pw_short');

        if (!preg_match('/[A-Z]/', $password))
            $errors[] = t('err_pw_uppercase');

        if (!preg_match('/[0-9]/', $password))
            $errors[] = t('err_pw_number');

        if ($password !== $password2)
            $errors[] = t('err_pw_mismatch');

        if (empty($errors)) {
            $pdo = getDB();

            // Duplicate email check
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$formData['email']]);
            if ($stmt->fetch()) {
                $errors[] = t('err_email_exists');
            }

            // Duplicate national ID check (only when a value was provided)
            if (!empty($formData['national_id'])) {
                $stmtNid = $pdo->prepare('SELECT id FROM users WHERE national_id = ? LIMIT 1');
                $stmtNid->execute([$formData['national_id']]);
                if ($stmtNid->fetch()) {
                    $errors[] = t('err_id_exists');
                }
            }
        }

        if (empty($errors)) {
            $pdo         = getDB();
            $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

            $stmt = $pdo->prepare('
                INSERT INTO users 
                    (full_name, email, phone, national_id, password_hash,
                     occupation, address, next_of_kin, next_of_kin_phone,
                     role, status)
                VALUES 
                    (:full_name, :email, :phone, :national_id, :password_hash,
                     :occupation, :address, :next_of_kin, :next_of_kin_phone,
                     "member", "pending")
            ');

            $stmt->execute([
                ':full_name'         => $formData['full_name'],
                ':email'             => $formData['email'],
                ':phone'             => $formData['phone'],
                ':national_id'       => $formData['national_id'] ?: null,
                ':password_hash'     => $passwordHash,
                ':occupation'        => $formData['occupation'],
                ':address'           => $formData['address'],
                ':next_of_kin'       => $formData['next_of_kin'],
                ':next_of_kin_phone' => $formData['next_of_kin_phone'],
            ]);

            $newUserId = (int) $pdo->lastInsertId();
            logActivity('REGISTER', "New member registration: {$formData['email']}", $newUserId);

            // Notify all admins
            $admins = $pdo->query("SELECT id FROM users WHERE role='admin' AND status='active'")->fetchAll();
            foreach ($admins as $admin) {
                createNotification(
                    $admin['id'],
                    'New Member Registration',
                    "A new member '{$formData['full_name']}' has registered and is awaiting approval.",
                    'info',
                    APP_URL . '/admin/members.php'
                );
            }

            // Send email verification link (if email is configured)
            $newUser = ['id' => $newUserId, 'full_name' => $formData['full_name'], 'email' => $formData['email']];
            $verificationSent = sendVerificationEmail($newUser, $pdo);

            // Also send the "we received your application" email
            sendRegistrationReceivedEmail([
                'full_name' => $formData['full_name'],
                'email'     => $formData['email'],
            ]);

            // Store in session for pending.php
            $_SESSION['pending_email']        = $formData['email'];
            $_SESSION['pending_name']         = $formData['full_name'];
            $_SESSION['verification_sent']    = $verificationSent;

            redirect(APP_URL . '/pending.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('reg_create_acct') ?> — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            --green:#00c471;--green-dark:#009954;--green-glow:rgba(0,196,113,0.2);
            --navy:#050f1c;--navy-mid:#0a1f35;--navy-light:#0f2d4a;
            --text:#e8f0f8;--muted:#7a94b0;--border:rgba(0,196,113,0.18);--input-bg:rgba(15,45,74,0.6);
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html{scroll-behavior:smooth}
        body{font-family:'DM Sans',sans-serif;background:var(--navy);color:var(--text);display:flex;min-height:100vh;overflow-x:hidden}

        /* LEFT PANEL */
        .left-panel{flex:0 0 40%;background:linear-gradient(160deg,#071628 0%,#0a2240 60%,#071a30 100%);display:flex;flex-direction:column;justify-content:space-between;padding:3rem;position:relative;overflow:hidden;min-height:100vh}
        .left-panel::before{content:'';position:absolute;width:450px;height:450px;border-radius:50%;background:radial-gradient(circle,rgba(0,196,113,0.13) 0%,transparent 65%);top:-80px;right:-120px;animation:glow 9s ease-in-out infinite}
        .left-panel::after{content:'';position:absolute;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(245,200,66,0.07) 0%,transparent 65%);bottom:-60px;left:-60px;animation:glow 13s ease-in-out infinite reverse}
        @keyframes glow{0%,100%{transform:scale(1) translate(0,0)}50%{transform:scale(1.1) translate(15px,-10px)}}

        .panel-logo{display:flex;align-items:center;gap:.75rem;text-decoration:none;position:relative;z-index:1}
        .panel-logo-icon{width:44px;height:44px;background:linear-gradient(135deg,var(--green),var(--green-dark));border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#fff;box-shadow:0 0 24px var(--green-glow)}
        .panel-logo-text{font-family:'Syne',sans-serif;font-weight:800;font-size:1.4rem;color:#fff;letter-spacing:-.02em}
        .panel-logo-text span{color:var(--green)}

        .panel-content{position:relative;z-index:1}
        .panel-tagline{font-family:'Syne',sans-serif;font-size:clamp(1.7rem,3vw,2.4rem);font-weight:800;line-height:1.1;letter-spacing:-.03em;margin-bottom:1rem}
        .panel-tagline .accent{color:var(--green)}
        .panel-sub{font-size:.9rem;color:var(--muted);line-height:1.7;margin-bottom:2rem}

        /* Step indicator on left */
        .steps-list{display:flex;flex-direction:column;gap:0}
        .step-item{display:flex;align-items:flex-start;gap:1rem;position:relative;padding-bottom:1.5rem}
        .step-item:last-child{padding-bottom:0}
        .step-item:not(:last-child)::after{content:'';position:absolute;left:15px;top:32px;bottom:0;width:2px;background:rgba(0,196,113,0.2)}
        .step-dot{width:32px;height:32px;border-radius:50%;background:var(--green-glow);border:2px solid var(--border);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:.8rem;font-weight:700;color:var(--green);flex-shrink:0;transition:all .3s}
        .step-dot.active{background:var(--green);color:#050f1c;border-color:var(--green);box-shadow:0 0 16px var(--green-glow)}
        .step-dot.done{background:rgba(0,196,113,.15);color:var(--green)}
        .step-info{}
        .step-name{font-size:.85rem;font-weight:600;margin-bottom:.1rem}
        .step-desc{font-size:.75rem;color:var(--muted)}

        .panel-footer{position:relative;z-index:1;font-size:.75rem;color:var(--muted)}

        /* RIGHT — FORM */
        .right-panel{flex:1;display:flex;align-items:flex-start;justify-content:center;padding:2.5rem 2rem;position:relative;background:var(--navy);overflow-y:auto}
        .right-panel::before{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(0,196,113,0.035) 1px,transparent 1px),linear-gradient(90deg,rgba(0,196,113,0.035) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}

        .form-box{width:100%;max-width:560px;position:relative;z-index:1;animation:fadeUp .5s ease both;padding-bottom:2rem}

        .form-header{margin-bottom:1.75rem}
        .form-header h1{font-family:'Syne',sans-serif;font-size:1.8rem;font-weight:800;letter-spacing:-.02em;margin-bottom:.3rem}
        .form-header p{font-size:.88rem;color:var(--muted)}
        .form-header p a{color:var(--green);text-decoration:none;font-weight:500}

        /* Progress bar */
        .progress-bar-wrap{margin-bottom:1.75rem}
        .progress-label{display:flex;justify-content:space-between;font-size:.75rem;color:var(--muted);margin-bottom:.4rem}
        .progress-track{height:4px;background:rgba(255,255,255,.07);border-radius:99px;overflow:hidden}
        .progress-fill{height:100%;border-radius:99px;background:var(--green);box-shadow:0 0 10px var(--green-glow);transition:width .4s ease}

        /* Section heading */
        .section-heading{display:flex;align-items:center;gap:.6rem;margin-bottom:1.1rem;margin-top:1.5rem}
        .section-heading:first-child{margin-top:0}
        .section-heading-icon{width:30px;height:30px;border-radius:8px;background:var(--green-glow);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--green);font-size:.85rem}
        .section-heading span{font-family:'Syne',sans-serif;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:rgba(232,240,248,.6)}

        /* Grid */
        .field-grid{display:grid;gap:1rem;margin-bottom:0}
        .field-grid.cols-2{grid-template-columns:1fr 1fr}
        .field-grid.cols-1{grid-template-columns:1fr}

        .field{margin-bottom:0}
        .field label{display:block;font-size:.78rem;font-weight:600;color:rgba(232,240,248,.75);text-transform:uppercase;letter-spacing:.05em;margin-bottom:.4rem}
        .field label .req{color:var(--green);margin-left:2px}

        .input-wrap{position:relative}
        .input-wrap .icon{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.95rem;pointer-events:none;transition:color .2s}
        .input-wrap input,.input-wrap textarea,.input-wrap select{width:100%;background:var(--input-bg);border:1px solid rgba(255,255,255,.08);border-radius:9px;padding:.72rem .85rem .72rem 2.6rem;font-family:'DM Sans',sans-serif;font-size:.9rem;color:var(--text);outline:none;transition:all .2s;backdrop-filter:blur(10px)}
        .input-wrap textarea{padding-top:.75rem;min-height:70px;resize:vertical}
        .input-wrap select{appearance:none}
        .input-wrap input::placeholder,.input-wrap textarea::placeholder{color:rgba(122,148,176,.55)}
        .input-wrap input:focus,.input-wrap textarea:focus,.input-wrap select:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow);background:rgba(15,45,74,.85)}
        .input-wrap:focus-within .icon{color:var(--green)}
        .input-wrap .toggle-pw{position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;font-size:.95rem;padding:0;transition:color .2s}
        .input-wrap .toggle-pw:hover{color:var(--green)}

        /* No-icon inputs */
        .input-plain input,.input-plain textarea{padding-left:.85rem}

        /* Password strength */
        .pw-strength-track{height:3px;border-radius:99px;background:rgba(255,255,255,.07);margin-top:.4rem;overflow:hidden}
        .pw-strength-bar{height:100%;border-radius:99px;width:0%;transition:width .3s,background .3s}
        .pw-strength-label{font-size:.72rem;color:var(--muted);margin-top:.25rem}

        /* Password match */
        .match-msg{font-size:.75rem;margin-top:.25rem}

        /* Alert */
        .alert-box{padding:.8rem 1rem;border-radius:10px;font-size:.875rem;margin-bottom:1.25rem;display:flex;align-items:flex-start;gap:.6rem}
        .alert-danger{background:rgba(220,53,69,.12);border:1px solid rgba(220,53,69,.3);color:#ff8b96}
        .alert-danger li{margin-left:.5rem}

        /* Checkbox */
        .check-field{display:flex;align-items:flex-start;gap:.75rem;margin:1rem 0}
        .check-field input[type=checkbox]{width:18px;height:18px;accent-color:var(--green);flex-shrink:0;margin-top:2px;cursor:pointer}
        .check-field label{font-size:.82rem;color:var(--muted);cursor:pointer;line-height:1.5}
        .check-field label a{color:var(--green);text-decoration:none}

        /* Submit */
        .btn-submit{width:100%;padding:.9rem;background:var(--green);color:#050f1c;border:none;border-radius:10px;font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;cursor:pointer;transition:all .25s;box-shadow:0 4px 30px rgba(0,196,113,.3);display:flex;align-items:center;justify-content:center;gap:.5rem;margin-top:.5rem}
        .btn-submit:hover{background:#00dc7e;transform:translateY(-2px);box-shadow:0 8px 40px rgba(0,196,113,.45)}
        .btn-submit:disabled{opacity:.7;cursor:not-allowed;transform:none}

        .divider{display:flex;align-items:center;gap:1rem;margin:1.25rem 0;font-size:.78rem;color:var(--muted)}
        .divider::before,.divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.07)}
        .back-link{display:flex;align-items:center;justify-content:center;gap:.4rem;font-size:.85rem;color:var(--muted);text-decoration:none;transition:color .2s}
        .back-link:hover{color:var(--green)}

        @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}

        @media(max-width:900px){.left-panel{display:none}.right-panel{padding:1.5rem 1.25rem}}
        @media(max-width:520px){.field-grid.cols-2{grid-template-columns:1fr}}
    </style>
</head>
<body>

<!-- Language Toggle -->
<div style="position:fixed;top:16px;right:20px;z-index:9999;display:flex;gap:6px;">
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=en"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='en' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='en' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇬🇧 EN
  </a>
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=sw"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='sw' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='sw' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇰🇪 SW
  </a>
</div>


<!-- LEFT PANEL -->
<div class="left-panel">
    <a href="<?= APP_URL ?>/home.php" class="panel-logo">
        <div class="panel-logo-icon"><i class="bi bi-bank2"></i></div>
        <span class="panel-logo-text">Smart<span>Chama</span></span>
    </a>

    <div class="panel-content">
        <h2 class="panel-tagline"><?= t('reg_tagline') ?></h2>
        <p class="panel-sub"><?= t('reg_panel_sub') ?></p>

        <div class="steps-list">
            <div class="step-item">
                <div class="step-dot active" id="sd1">1</div>
                <div class="step-info">
                    <div class="step-name"><?= t('reg_step1_name') ?></div>
                    <div class="step-desc"><?= t('reg_step1_desc') ?></div>
                </div>
            </div>
            <div class="step-item">
                <div class="step-dot" id="sd2">2</div>
                <div class="step-info">
                    <div class="step-name"><?= t('reg_step2_name') ?></div>
                    <div class="step-desc"><?= t('reg_step2_desc') ?></div>
                </div>
            </div>
            <div class="step-item">
                <div class="step-dot" id="sd3">3</div>
                <div class="step-info">
                    <div class="step-name"><?= t('reg_step3_name') ?></div>
                    <div class="step-desc"><?= t('reg_step3_desc') ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="panel-footer">© <?= date('Y') ?> SmartChama. <?= t('home_footer_rights') ?></div>
</div>

<!-- RIGHT PANEL -->
<div class="right-panel">
    <div class="form-box">
        <div class="form-header">
            <h1><?= t('reg_create_acct') ?></h1>
            <p><?= t('reg_already_member') ?> <a href="<?= APP_URL ?>/index.php"><?= t('reg_sign_in_here') ?></a></p>
        </div>

        <!-- Progress -->
        <div class="progress-bar-wrap">
            <div class="progress-label">
                <span id="progressLabel"><?= t('reg_step_label') ?> 1 <?= t('reg_step_of') ?> 3 — <?= t('reg_personal_info') ?></span>
                <span id="progressPct">33%</span>
            </div>
            <div class="progress-track">
                <div class="progress-fill" id="progressFill" style="width:33%"></div>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
        <div class="alert-box alert-danger">
            <i class="bi bi-exclamation-triangle-fill" style="flex-shrink:0;margin-top:2px"></i>
            <ul style="list-style:none;padding:0;margin:0">
                <?php foreach($errors as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <form method="POST" action="" novalidate id="regForm">
            <?= csrfField() ?>

            <!-- STEP 1: Personal Info -->
            <div class="form-step" id="step1">
                <div class="section-heading">
                    <div class="section-heading-icon"><i class="bi bi-person"></i></div>
                    <span><?= t('reg_personal_info') ?></span>
                </div>

                <div class="field-grid cols-1" style="margin-bottom:1rem">
                    <div class="field">
                        <label><?= t('register_name') ?> <span class="req">*</span></label>
                        <div class="input-wrap">
                            <i class="bi bi-person icon"></i>
                            <input type="text" name="full_name" placeholder="e.g. Jane Wambui Mwangi"
                                   value="<?= htmlspecialchars($formData['full_name'] ?? '') ?>" required>
                        </div>
                    </div>
                </div>

                <div class="field-grid cols-2" style="margin-bottom:1rem">
                    <div class="field">
                        <label><?= t('register_email') ?> <span class="req">*</span></label>
                        <div class="input-wrap">
                            <i class="bi bi-envelope icon"></i>
                            <input type="email" name="email" placeholder="you@email.com"
                                   value="<?= htmlspecialchars($formData['email'] ?? '') ?>" required>
                        </div>
                    </div>
                    <div class="field">
                        <label><?= t('register_phone') ?> <span class="req">*</span></label>
                        <div class="input-wrap">
                            <i class="bi bi-phone icon"></i>
                            <input type="tel" name="phone" placeholder="0712345678"
                                   value="<?= htmlspecialchars($formData['phone'] ?? '') ?>" required>
                        </div>
                    </div>
                </div>

                <div class="field-grid cols-2" style="margin-bottom:1rem">
                    <div class="field">
                        <label><?= t('reg_national_id') ?> <span class="req">*</span></label>
                        <div class="input-wrap">
                            <i class="bi bi-card-text icon"></i>
                            <input type="text" name="national_id" placeholder="12345678"
                                   value="<?= htmlspecialchars($formData['national_id'] ?? '') ?>" required>
                        </div>
                    </div>
                    <div class="field">
                        <label><?= t('reg_occupation') ?></label>
                        <div class="input-wrap">
                            <i class="bi bi-briefcase icon"></i>
                            <input type="text" name="occupation" placeholder="e.g. Nurse, Teacher"
                                   value="<?= htmlspecialchars($formData['occupation'] ?? '') ?>">
                        </div>
                    </div>
                </div>

                <div class="field-grid cols-1" style="margin-bottom:1rem">
                    <div class="field">
                        <label><?= t('reg_address') ?></label>
                        <div class="input-wrap input-plain">
                            <textarea name="address" placeholder="Estate, Town, County"><?= htmlspecialchars($formData['address'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>

                <button type="button" class="btn-submit" onclick="goStep(2)">
                    <?= t('reg_continue') ?> <i class="bi bi-arrow-right"></i>
                </button>
            </div>

            <!-- STEP 2: Next of Kin -->
            <div class="form-step" id="step2" style="display:none">
                <div class="section-heading">
                    <div class="section-heading-icon"><i class="bi bi-people"></i></div>
                    <span><?= t('reg_next_of_kin') ?></span>
                </div>

                <div class="field-grid cols-2" style="margin-bottom:1rem">
                    <div class="field">
                        <label><?= t('register_name') ?></label>
                        <div class="input-wrap">
                            <i class="bi bi-people icon"></i>
                            <input type="text" name="next_of_kin" placeholder="<?= t('reg_step2_name') ?>"
                                   value="<?= htmlspecialchars($formData['next_of_kin'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="field">
                        <label><?= t('register_phone') ?></label>
                        <div class="input-wrap">
                            <i class="bi bi-telephone icon"></i>
                            <input type="tel" name="next_of_kin_phone" placeholder="0712345678"
                                   value="<?= htmlspecialchars($formData['next_of_kin_phone'] ?? '') ?>">
                        </div>
                    </div>
                </div>

                <div style="display:flex;gap:.75rem;margin-top:.5rem">
                    <button type="button" class="btn-submit" style="background:rgba(255,255,255,.07);color:var(--text);box-shadow:none;flex:0 0 auto;width:auto;padding:.9rem 1.5rem" onclick="goStep(1)">
                        <i class="bi bi-arrow-left"></i> <?= t('reg_back') ?>
                    </button>
                    <button type="button" class="btn-submit" style="flex:1" onclick="goStep(3)">
                        <?= t('reg_continue') ?> <i class="bi bi-arrow-right"></i>
                    </button>
                </div>
            </div>

            <!-- STEP 3: Security -->
            <div class="form-step" id="step3" style="display:none">
                <div class="section-heading">
                    <div class="section-heading-icon"><i class="bi bi-shield-lock"></i></div>
                    <span><?= t('reg_acct_security') ?></span>
                </div>

                <div class="field-grid cols-2" style="margin-bottom:.25rem">
                    <div class="field">
                        <label><?= t('reg_password_lbl') ?> <span class="req">*</span></label>
                        <div class="input-wrap">
                            <i class="bi bi-lock icon"></i>
                            <input type="password" name="password" id="pw1" placeholder="<?= t('reg_pw_hint') ?>" required>
                            <button type="button" class="toggle-pw" data-target="pw1"><i class="bi bi-eye"></i></button>
                        </div>
                        <div class="pw-strength-track"><div class="pw-strength-bar" id="strengthBar"></div></div>
                        <div class="pw-strength-label" id="strengthLabel"><?= t('reg_pw_hint') ?></div>
                    </div>
                    <div class="field">
                        <label><?= t('register_confirm') ?> <span class="req">*</span></label>
                        <div class="input-wrap">
                            <i class="bi bi-lock-fill icon"></i>
                            <input type="password" name="password_confirm" id="pw2" placeholder="<?= t('reg_pw_repeat') ?>" required>
                            <button type="button" class="toggle-pw" data-target="pw2"><i class="bi bi-eye"></i></button>
                        </div>
                        <div class="match-msg" id="matchMsg"></div>
                    </div>
                </div>

                <div class="check-field">
                    <input type="checkbox" name="terms" id="terms" required>
                    <label for="terms"><?= t('reg_terms') ?></label>
                </div>

                <div style="display:flex;gap:.75rem">
                    <button type="button" class="btn-submit" style="background:rgba(255,255,255,.07);color:var(--text);box-shadow:none;flex:0 0 auto;width:auto;padding:.9rem 1.5rem" onclick="goStep(2)">
                        <i class="bi bi-arrow-left"></i> <?= t('reg_back') ?>
                    </button>
                    <button type="submit" class="btn-submit" style="flex:1" id="submitBtn">
                        <i class="bi bi-person-check-fill"></i> <?= t('register_title') ?>
                    </button>
                </div>
            </div>
        </form>

        <div class="divider"><?= t('lbl_or') ?></div>
        <a href="<?= APP_URL ?>/home.php" class="back-link"><i class="bi bi-arrow-left"></i> <?= t('reg_back_home') ?></a>
    </div>
</div>

<script>
const steps = {
    1: { label: '<?= t("reg_step_label") ?> 1 <?= t("reg_step_of") ?> 3 — <?= t("reg_personal_info") ?>', pct: '33%' },
    2: { label: '<?= t("reg_step_label") ?> 2 <?= t("reg_step_of") ?> 3 — <?= t("reg_next_of_kin") ?>', pct: '66%' },
    3: { label: '<?= t("reg_step_label") ?> 3 <?= t("reg_step_of") ?> 3 — <?= t("reg_acct_security") ?>', pct: '100%' },
};
const dots  = { 1: 'sd1', 2: 'sd2', 3: 'sd3' };

function goStep(n) {
    document.querySelectorAll('.form-step').forEach(s => s.style.display = 'none');
    document.getElementById('step' + n).style.display = 'block';
    document.getElementById('progressLabel').textContent = steps[n].label;
    document.getElementById('progressPct').textContent   = steps[n].pct;
    document.getElementById('progressFill').style.width  = steps[n].pct;
    // Update side dots
    for (let i = 1; i <= 3; i++) {
        const dot = document.getElementById(dots[i]);
        dot.classList.remove('active','done');
        if (i < n)  dot.classList.add('done');
        if (i === n) dot.classList.add('active');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// If there were PHP validation errors, jump to step 3 if password issue, else stay step 1
<?php if (!empty($errors)): ?>
goStep(1); // Stay on step 1 if errors (form re-shows)
<?php endif; ?>

// Toggle password
document.querySelectorAll('.toggle-pw').forEach(btn => {
    btn.addEventListener('click', function() {
        const input = document.getElementById(this.dataset.target);
        const icon  = this.querySelector('i');
        input.type  = input.type === 'password' ? 'text' : 'password';
        icon.className = input.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
    });
});

// Password strength
const pw1 = document.getElementById('pw1');
const bar = document.getElementById('strengthBar');
const lbl = document.getElementById('strengthLabel');
const colors = ['','#ef4444','#f97316','#eab308','#22c55e','#16a34a'];
const labels = ['','<?= t("pw_very_weak") ?>','<?= t("pw_weak") ?>','<?= t("pw_fair") ?>','<?= t("pw_strong") ?>','<?= t("pw_very_strong") ?>'];

pw1.addEventListener('input', function() {
    const v = this.value;
    let s = 0;
    if (v.length >= 8)          s++;
    if (v.length >= 12)         s++;
    if (/[A-Z]/.test(v))        s++;
    if (/[0-9]/.test(v))        s++;
    if (/[^A-Za-z0-9]/.test(v)) s++;
    bar.style.width      = (s * 20) + '%';
    bar.style.background = colors[s] || '#374151';
    lbl.textContent      = s > 0 ? labels[s] : '<?= t("reg_pw_hint") ?>';
    lbl.style.color      = colors[s] || 'var(--muted)';
});

// Password match
const pw2  = document.getElementById('pw2');
const mmsg = document.getElementById('matchMsg');
pw2.addEventListener('input', function() {
    if (!this.value) { mmsg.textContent = ''; return; }
    if (this.value === pw1.value) {
        mmsg.textContent = '<?= t("pw_match") ?>';
        mmsg.style.color = 'var(--green)';
    } else {
        mmsg.textContent = '<?= t("pw_no_match") ?>';
        mmsg.style.color = '#ff8b96';
    }
});

// Submit spinner
document.getElementById('regForm').addEventListener('submit', function() {
    const btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.innerHTML = '<span style="width:16px;height:16px;border:2px solid #050f1c;border-top-color:transparent;border-radius:50%;animation:spin .6s linear infinite;display:inline-block"></span> <?= t("reg_creating") ?>';
});
</script>
<style>@keyframes spin{to{transform:rotate(360deg)}}</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.alert-box, .alert-danger, .alert-warning, .alert-success').forEach(function(alert) {
        setTimeout(function() {
            alert.style.transition = 'opacity .6s ease, transform .6s ease, max-height .6s ease, margin .6s ease, padding .6s ease';
            alert.style.opacity    = '0';
            alert.style.transform  = 'translateY(-8px)';
            alert.style.maxHeight  = '0';
            alert.style.margin     = '0';
            alert.style.padding    = '0';
            alert.style.overflow   = 'hidden';
            setTimeout(function() { if(alert.parentNode) alert.remove(); }, 650);
        }, 5000);
    });
});
</script>
</body>
</html>
