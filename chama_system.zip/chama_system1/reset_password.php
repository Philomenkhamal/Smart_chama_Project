<?php
// Bypass ngrok browser warning
@header('ngrok-skip-browser-warning: true');
if (!defined('ROOT')) define('ROOT', __DIR__);
require_once ROOT . '/includes/functions.php';
if (!dbIsReady()) { header('Location: ' . APP_URL . '/setup.php'); exit; }
startSession();
if (isLoggedIn()) redirect(APP_URL . '/member/dashboard.php');

$pdo    = getDB();
$token  = sanitize($_GET['token'] ?? '');
$errors = [];
$done   = false;
$reset  = null;

if ($token) {
    $stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token=? AND used=0 AND expires_at > NOW() LIMIT 1");
    $stmt->execute([$token]);
    $reset = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf($_POST['csrf_token'] ?? '') && $reset) {
    $pass    = $_POST['password']         ?? '';
    $confirm = $_POST['password_confirm'] ?? '';
    $postTok = sanitize($_POST['token']   ?? '');

    if (strlen($pass) < 8)             $errors[] = t('err_reset_pw_short');
    if ($pass !== $confirm)             $errors[] = t('err_reset_pw_mismatch');
    if (!preg_match('/[A-Z]/', $pass))  $errors[] = t('err_reset_pw_upper');
    if (!preg_match('/[0-9]/', $pass))  $errors[] = t('err_reset_pw_num');

    if (empty($errors)) {
        $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 10]);
        $pdo->prepare("UPDATE users SET password_hash=? WHERE email=?")->execute([$hash, $reset['email']]);
        $pdo->prepare("UPDATE password_resets SET used=1 WHERE token=?")->execute([$postTok]);
        logActivity('PASSWORD_RESET_DONE', 'Password reset for ' . $reset['email']);
        $done = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('reset_title') ?> — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            --green:      #00c471;
            --green-dark: #009954;
            --green-glow: rgba(0,196,113,0.2);
            --navy:       #050f1c;
            --navy-light: #0f2d4a;
            --text:       #e8f0f8;
            --muted:      #7a94b0;
            --border:     rgba(0,196,113,0.18);
            --input-bg:   rgba(15,45,74,0.6);
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%}
        body{font-family:'DM Sans',sans-serif;background:var(--navy);color:var(--text);display:flex;min-height:100vh;overflow-x:hidden}

        .left-panel{flex:0 0 45%;background:linear-gradient(160deg,#071628 0%,#0a2240 50%,#061320 100%);display:flex;flex-direction:column;justify-content:space-between;padding:3rem;position:relative;overflow:hidden}
        .left-panel::before{content:'';position:absolute;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(0,196,113,0.15) 0%,transparent 65%);top:-100px;right:-150px;animation:glow 8s ease-in-out infinite}
        .left-panel::after{content:'';position:absolute;width:350px;height:350px;border-radius:50%;background:radial-gradient(circle,rgba(0,196,113,0.08) 0%,transparent 65%);bottom:-80px;left:-80px;animation:glow 11s ease-in-out infinite reverse}
        @keyframes glow{0%,100%{transform:scale(1) translate(0,0);opacity:1}50%{transform:scale(1.15) translate(20px,-15px);opacity:0.7}}

        .panel-logo{display:flex;align-items:center;gap:.75rem;text-decoration:none;position:relative;z-index:1}
        .panel-logo-icon{width:44px;height:44px;background:linear-gradient(135deg,var(--green),var(--green-dark));border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#fff;box-shadow:0 0 24px var(--green-glow)}
        .panel-logo-text{font-family:'Syne',sans-serif;font-weight:800;font-size:1.4rem;color:#fff;letter-spacing:-.02em}
        .panel-logo-text span{color:var(--green)}

        .panel-content{position:relative;z-index:1;animation:fadeUp .6s ease .2s both}
        .panel-tagline{font-family:'Syne',sans-serif;font-size:clamp(1.9rem,3.5vw,2.8rem);font-weight:800;line-height:1.1;letter-spacing:-.03em;margin-bottom:1.2rem}
        .panel-tagline .accent{color:var(--green)}
        .panel-sub{font-size:.95rem;color:var(--muted);line-height:1.7;max-width:340px;margin-bottom:2.5rem}
        .panel-features{display:flex;flex-direction:column;gap:.9rem}
        .panel-feature{display:flex;align-items:center;gap:.75rem;font-size:.88rem;color:rgba(232,240,248,.75)}
        .panel-feature-dot{width:28px;height:28px;border-radius:8px;background:var(--green-glow);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:.85rem;color:var(--green);flex-shrink:0}
        .panel-footer{position:relative;z-index:1;font-size:.75rem;color:var(--muted)}

        .right-panel{flex:1;display:flex;align-items:center;justify-content:center;padding:2rem;position:relative;background:var(--navy)}
        .right-panel::before{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(0,196,113,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,196,113,0.04) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}

        .form-box{width:100%;max-width:420px;position:relative;z-index:1;animation:fadeUp .6s ease .1s both}
        .form-header{margin-bottom:2rem}
        .form-header h1{font-family:'Syne',sans-serif;font-size:1.9rem;font-weight:800;letter-spacing:-.02em;margin-bottom:.35rem}
        .form-header p{font-size:.9rem;color:var(--muted)}

        .alert-box{padding:.85rem 1rem;border-radius:10px;font-size:.875rem;margin-bottom:1.25rem;display:flex;align-items:flex-start;gap:.6rem;animation:shake .4s ease}
        .alert-danger{background:rgba(220,53,69,.12);border:1px solid rgba(220,53,69,.3);color:#ff8b96}
        .alert-warning{background:rgba(255,193,7,.12);border:1px solid rgba(255,193,7,.3);color:#ffd966}
        @keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-6px)}40%,80%{transform:translateX(6px)}}

        .field{margin-bottom:1.2rem}
        .field label{display:block;font-size:.82rem;font-weight:600;color:rgba(232,240,248,.8);text-transform:uppercase;letter-spacing:.06em;margin-bottom:.45rem}
        .input-wrap{position:relative}
        .input-wrap .icon{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:1rem;pointer-events:none;transition:color .2s}
        .input-wrap input{width:100%;background:var(--input-bg);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:.8rem .9rem .8rem 2.75rem;font-family:'DM Sans',sans-serif;font-size:.95rem;color:var(--text);outline:none;transition:all .2s;backdrop-filter:blur(10px)}
        .input-wrap input::placeholder{color:rgba(122,148,176,.6)}
        .input-wrap input:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow);background:rgba(15,45,74,.8)}
        .input-wrap:focus-within .icon{color:var(--green)}
        .input-wrap .toggle-pw{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;font-size:1rem;padding:0;transition:color .2s}
        .input-wrap .toggle-pw:hover{color:var(--green)}

        /* Strength bar */
        .strength-wrap{margin-top:.5rem}
        .strength-bar{height:4px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden}
        .strength-fill{height:100%;width:0;border-radius:99px;transition:all .3s}
        .strength-label{font-size:.72rem;margin-top:.25rem;transition:color .3s}

        /* Match indicator */
        .match-msg{font-size:.72rem;margin-top:.25rem;min-height:1rem}

        .btn-submit{width:100%;padding:.9rem;background:var(--green);color:#050f1c;border:none;border-radius:10px;font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;cursor:pointer;transition:all .25s;box-shadow:0 4px 30px rgba(0,196,113,.3);margin-top:.5rem;display:flex;align-items:center;justify-content:center;gap:.5rem}
        .btn-submit:hover{background:#00dc7e;transform:translateY(-2px);box-shadow:0 8px 40px rgba(0,196,113,.45)}

        .divider{display:flex;align-items:center;gap:1rem;margin:1.5rem 0;font-size:.78rem;color:var(--muted)}
        .divider::before,.divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.07)}
        .back-link{display:flex;align-items:center;justify-content:center;gap:.4rem;font-size:.85rem;color:var(--muted);text-decoration:none;transition:color .2s}
        .back-link:hover{color:var(--green)}

        .success-icon{width:72px;height:72px;background:rgba(0,196,113,.15);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;font-size:2rem;color:var(--green);animation:pop .5s ease both}
        @keyframes pop{from{transform:scale(0.5);opacity:0}to{transform:scale(1);opacity:1}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}
        @media(max-width:768px){.left-panel{display:none}.right-panel{padding:1.5rem 1.25rem}}
    </style>
</head>
<body>

<!-- Language Toggle -->
<div style="position:fixed;top:16px;right:20px;z-index:9999;display:flex;gap:6px;">
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=en"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='en' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='en' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇬🇧 EN
  </a>
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=sw"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='sw' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='sw' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇰🇪 SW
  </a>
</div>


<!-- Left Panel -->
<div class="left-panel">
    <a href="<?= APP_URL ?>/home.php" class="panel-logo">
        <div class="panel-logo-icon"><i class="bi bi-bank2"></i></div>
        <span class="panel-logo-text">Chama<span>Ledger</span></span>
    </a>
    <div class="panel-content">
        <?php if ($done): ?>
        <h2 class="panel-tagline"><?= t('reset_done_short') ?></h2>
        <p class="panel-sub"><?= t('reset_done_msg') ?></p>
        <?php elseif (!$reset && $token): ?>
        <h2 class="panel-tagline"><?= t('reset_expired_short') ?></h2>
        <p class="panel-sub"><?= t('reset_expired_msg') ?></p>
        <?php else: ?>
        <h2 class="panel-tagline"><?= t('reset_new_pw_title') ?></h2>
        <p class="panel-sub"><?= t('reset_sub') ?></p>
        <?php endif; ?>
        <div class="panel-features">
            <div class="panel-feature"><div class="panel-feature-dot"><i class="bi bi-shield-check"></i></div><?= t('reset_min8') ?></div>
            <div class="panel-feature"><div class="panel-feature-dot"><i class="bi bi-type"></i></div><?= t('reset_uppercase') ?></div>
            <div class="panel-feature"><div class="panel-feature-dot"><i class="bi bi-lock"></i></div><?= t('reset_single_use') ?></div>
        </div>
    </div>
    <div class="panel-footer">© <?= date('Y') ?> ChamaLedger. All rights reserved.</div>
</div>

<!-- Right Panel -->
<div class="right-panel">
    <div class="form-box">

        <?php if ($done): ?>
        <div style="text-align:center">
            <div class="success-icon"><i class="bi bi-check-lg"></i></div>
            <div class="form-header" style="text-align:center">
                <h1><?= t('reset_done_title') ?></h1>
                <p><?= t('reset_done_msg') ?></p>
            </div>
            <a href="<?= APP_URL ?>/index.php" class="btn-submit">
                <i class="bi bi-box-arrow-in-right"></i> Sign In Now
            </a>
        </div>

        <?php elseif (!$reset && $token): ?>
        <div style="text-align:center">
            <div class="success-icon" style="background:rgba(239,68,68,.12);color:#ff8b96"><i class="bi bi-clock-history"></i></div>
            <div class="form-header" style="text-align:center">
                <h1><?= t('reset_link_expired') ?></h1>
                <p><?= t('err_reset_expired') ?></p>
            </div>
            <a href="<?= APP_URL ?>/forgot_password.php" class="btn-submit">
                <i class="bi bi-arrow-repeat"></i> Request New Link
            </a>
        </div>

        <?php else: ?>
        <div class="form-header">
            <h1><?= t('reset_set_new') ?></h1>
            <p><?= t('reset_almost') ?></p>
        </div>

        <?php if (!empty($errors)): ?>
        <div class="alert-box alert-danger">
            <i class="bi bi-exclamation-triangle-fill" style="flex-shrink:0;margin-top:2px"></i>
            <div><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
        </div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">

            <div class="field">
                <label><?= t('reset_new_pw') ?></label>
                <div class="input-wrap">
                    <i class="bi bi-lock icon"></i>
                    <input type="password" name="password" id="newPass" placeholder="Min 8 characters" required autofocus>
                    <button type="button" class="toggle-pw" onclick="togglePw('newPass', this)"><i class="bi bi-eye"></i></button>
                </div>
                <div class="strength-wrap">
                    <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
                    <div class="strength-label" id="strengthLabel"></div>
                </div>
            </div>

            <div class="field">
                <label><?= t('register_confirm') ?></label>
                <div class="input-wrap">
                    <i class="bi bi-lock-fill icon"></i>
                    <input type="password" name="password_confirm" id="confirmPass" placeholder="Repeat password" required>
                    <button type="button" class="toggle-pw" onclick="togglePw('confirmPass', this)"><i class="bi bi-eye"></i></button>
                </div>
                <div class="match-msg" id="matchMsg"></div>
            </div>

            <button type="submit" class="btn-submit">
                <i class="bi bi-shield-check"></i> Update Password
            </button>
        </form>

        <div class="divider">or</div>
        <a href="<?= APP_URL ?>/index.php" class="back-link">
            <i class="bi bi-arrow-left"></i> <?= t('reset_back_signin') ?>
        </a>
        <?php endif; ?>

    </div>
</div>

<script>
function togglePw(id, btn) {
    var inp = document.getElementById(id);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    btn.querySelector('i').className = inp.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
}

var newPass = document.getElementById('newPass');
if (newPass) {
    newPass.addEventListener('input', function() {
        var v = this.value, score = 0;
        if (v.length >= 8)           score++;
        if (/[A-Z]/.test(v))         score++;
        if (/[0-9]/.test(v))         score++;
        if (/[^A-Za-z0-9]/.test(v))  score++;
        var levels = [
            { w: '25%', c: '#ef4444', t: 'Weak'   },
            { w: '50%', c: '#f59e0b', t: 'Fair'   },
            { w: '75%', c: '#3b82f6', t: 'Good'   },
            { w: '100%',c: '#00c471', t: 'Strong' }
        ];
        var l = v ? levels[Math.max(0, score - 1)] : { w: '0%', c: '', t: '' };
        document.getElementById('strengthFill').style.width      = l.w;
        document.getElementById('strengthFill').style.background = l.c;
        document.getElementById('strengthLabel').textContent     = l.t;
        document.getElementById('strengthLabel').style.color     = l.c;
    });
}

var confirmPass = document.getElementById('confirmPass');
if (confirmPass) {
    confirmPass.addEventListener('input', function() {
        var match = this.value === document.getElementById('newPass').value;
        var el = document.getElementById('matchMsg');
        if (!this.value) { el.textContent = ''; return; }
        el.textContent = match ? '✓ Passwords match' : '✗ Passwords do not match';
        el.style.color = match ? '#00c471' : '#ef4444';
    });
}
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.alert-box, .alert-danger, .alert-warning, .alert-success').forEach(function(alert) {
        setTimeout(function() {
            alert.style.transition = 'opacity .6s ease, transform .6s ease, max-height .6s ease, margin .6s ease, padding .6s ease';
            alert.style.opacity    = '0';
            alert.style.transform  = 'translateY(-8px)';
            alert.style.maxHeight  = '0';
            alert.style.margin     = '0';
            alert.style.padding    = '0';
            alert.style.overflow   = 'hidden';
            setTimeout(function() { if(alert.parentNode) alert.remove(); }, 650);
        }, 5000);
    });
});
</script>
</body>
</html>
