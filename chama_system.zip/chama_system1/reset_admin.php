<?php
// ─── PRODUCTION GUARD ─────────────────────────────────────────────────────────
// This file should be DELETED after first use.
// Block access if a SETUP_SECRET env variable is set (production safety).
if (!empty(getenv('DISABLE_SETUP')) || !empty($_ENV['DISABLE_SETUP'])) {
    http_response_code(404);
    die('Not found.');
}
// ──────────────────────────────────────────────────────────────────────────────
/**
 * ChamaLedger — Admin Password Reset
 * Visit this page ONCE to fix admin login, then DELETE it.
 * URL: http://localhost/chama_system/reset_admin.php
 */
require_once __DIR__ . '/config/db.php';

$email    = 'admin@chama.local';
$password = 'Admin@1234';
$hash     = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
$verified = password_verify($password, $hash);

try {
    $pdo = getDB();

    // Check if admin exists
    $existing = $pdo->query("SELECT id FROM users WHERE role='admin' LIMIT 1")->fetch();

    if ($existing) {
        $pdo->prepare("UPDATE users SET password_hash=?, email=?, status='active' WHERE role='admin'")
            ->execute([$hash, $email]);
        $action = 'Password updated for existing admin account.';
    } else {
        $pdo->prepare("
            INSERT INTO users (full_name, email, phone, national_id, password_hash, role, status, membership_number, joined_date)
            VALUES ('System Administrator', ?, '0700000000', 'ADMIN001', ?, 'admin', 'active', 'CHM-ADMIN', CURDATE())
        ")->execute([$email, $hash]);
        $action = 'New admin account created.';
    }
    $success = true;
} catch (Exception $e) {
    $success = false;
    $action  = 'ERROR: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Admin — ChamaLedger</title>
    <style>
        body { font-family: sans-serif; background: #050f1c; color: #e8f0f8; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        .card { background: #0a1f35; border: 1px solid rgba(0,196,113,0.2); border-radius: 16px; padding: 2.5rem; max-width: 480px; width: 100%; text-align: center; }
        h2 { font-size: 1.5rem; margin-bottom: 1.5rem; }
        .ok  { color: #00c471; }
        .err { color: #ff8b96; }
        table { width: 100%; border-collapse: collapse; margin: 1.5rem 0; text-align: left; }
        td { padding: .5rem .75rem; border-bottom: 1px solid rgba(255,255,255,.07); font-size: .9rem; }
        td:first-child { color: #7a94b0; width: 40%; }
        code { background: rgba(0,196,113,.1); padding: .15rem .4rem; border-radius: 4px; color: #00c471; }
        .btn { display: inline-block; margin-top: 1rem; padding: .75rem 2rem; background: #00c471; color: #050f1c; font-weight: 700; border-radius: 8px; text-decoration: none; }
        .warn { margin-top: 1.25rem; padding: .75rem 1rem; background: rgba(255,193,7,.1); border: 1px solid rgba(255,193,7,.3); border-radius: 8px; font-size: .82rem; color: #ffd966; }
    </style>
</head>
<body>
<div class="card">
    <h2><?= $success ? '✅' : '❌' ?> Admin Reset</h2>

    <?php if ($success): ?>
    <p class="ok"><?= htmlspecialchars($action) ?></p>
    <table>
        <tr><td>Email</td><td><code><?= $email ?></code></td></tr>
        <tr><td>Password</td><td><code><?= $password ?></code></td></tr>
        <tr><td>Hash verified</td><td class="ok"><?= $verified ? '✅ Yes' : '❌ No' ?></td></tr>
        <tr><td>PHP version</td><td><?= PHP_VERSION ?></td></tr>
    </table>
    <a href="<?= defined('APP_URL') ? APP_URL : 'http://localhost/chama_system' ?>/index.php" class="btn">Go to Login →</a>
    <div class="warn">⚠️ Delete <code>reset_admin.php</code> after logging in!</div>
    <?php else: ?>
    <p class="err"><?= htmlspecialchars($action) ?></p>
    <p style="color:#7a94b0;font-size:.85rem;margin-top:1rem">Check your database connection in config/db.php</p>
    <?php endif; ?>
</div>
</body>
</html>
