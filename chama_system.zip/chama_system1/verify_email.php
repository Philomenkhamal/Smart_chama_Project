<?php
/**
 * ChamaLedger — Email Verification
 * GET /verify_email.php?token=XXXX
 */
require_once __DIR__ . '/includes/functions.php';
startSession();

$token  = trim($_GET['token'] ?? '');
$status = 'invalid'; // invalid | expired | already | success

if ($token) {
    $pdo  = getDB();
    $stmt = $pdo->prepare("
        SELECT id, full_name, email, email_verified, verify_token_expires
        FROM users WHERE verify_token = ? LIMIT 1
    ");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        $status = 'invalid';
    } elseif ($user['email_verified']) {
        $status = 'already';
    } elseif (strtotime($user['verify_token_expires']) < time()) {
        $status = 'expired';
    } else {
        // Mark verified
        $pdo->prepare("
            UPDATE users
            SET email_verified=1, verify_token=NULL, verify_token_expires=NULL
            WHERE id=?
        ")->execute([$user['id']]);
        logActivity('EMAIL_VERIFIED', "Email verified: {$user['email']}", $user['id']);
        $status = 'success';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= t('verify_page_title') ?> — <?= APP_NAME ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:Arial,sans-serif;background:#f0f4f8;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
  .card{background:#fff;border-radius:16px;box-shadow:0 4px 32px rgba(0,0,0,.1);padding:3rem 2.5rem;text-align:center;max-width:460px;width:100%}
  .icon{font-size:4rem;margin-bottom:1.25rem;display:block}
  h1{font-size:1.5rem;font-weight:800;margin-bottom:.75rem;color:#060e1a}
  p{color:#6b7280;line-height:1.7;margin-bottom:1.5rem;font-size:.95rem}
  .btn{display:inline-block;background:#00c471;color:#060e1a;padding:.75rem 2rem;border-radius:10px;text-decoration:none;font-weight:700;font-size:.95rem;transition:background .2s}
  .btn:hover{background:#009954}
  .btn-outline{background:#fff;border:2px solid #00c471;color:#00c471;margin-left:.5rem}
  .btn-outline:hover{background:#f0fdf4}
</style>
</head>
<body>

<!-- Language Toggle -->
<div style="position:fixed;top:16px;right:20px;z-index:9999;display:flex;gap:6px;">
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=en"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='en' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='en' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇬🇧 EN
  </a>
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=sw"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='sw' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='sw' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇰🇪 SW
  </a>
</div>

<div class="card">
<?php if ($status === 'success'): ?>
  <span class="icon">✅</span>
  <h1><?= t('verify_email_success') ?></h1>
  <p><?= t('verify_email_success_sub') ?></p>
  <a href="<?= APP_URL ?>/index.php" class="btn"><?= t('verify_goto_login') ?></a>

<?php elseif ($status === 'already'): ?>
  <span class="icon">✔️</span>
  <h1><?= t('verify_email_already') ?></h1>
  <p><?= t('verify_email_already_sub') ?></p>
  <a href="<?= APP_URL ?>/index.php" class="btn"><?= t('verify_goto_login') ?></a>

<?php elseif ($status === 'expired'): ?>
  <span class="icon">⏰</span>
  <h1><?= t('verify_email_expired') ?></h1>
  <p><?= t('verify_email_expired_sub') ?></p>
  <a href="<?= APP_URL ?>/resend_verification.php" class="btn"><?= t('verify_resend_btn') ?></a>

<?php else: ?>
  <span class="icon">❌</span>
  <h1><?= t('verify_email_invalid') ?></h1>
  <p><?= t('verify_email_invalid_sub') ?></p>
  <a href="<?= APP_URL ?>/resend_verification.php" class="btn"><?= t('verify_resend_btn') ?></a>
  <br><br>
  <a href="<?= APP_URL ?>/index.php" style="color:#6b7280;font-size:.85rem"><?= t('verify_back_login') ?></a>
<?php endif; ?>
</div>
</body>
</html>
