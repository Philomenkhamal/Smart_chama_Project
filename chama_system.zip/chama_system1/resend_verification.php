<?php
/**
 * ChamaLedger — Resend Verification Email
 */
require_once __DIR__ . '/includes/functions.php';
startSession();

$sent   = false;
$error  = '';
$email  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf($_POST['csrf_token'] ?? '')) {
    $email = strtolower(trim($_POST['email'] ?? ''));

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $pdo  = getDB();
        $stmt = $pdo->prepare("SELECT id, full_name, email, email_verified, status FROM users WHERE email=? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // Always show success to prevent email enumeration
        if ($user && !$user['email_verified'] && $user['status'] !== 'rejected') {
            sendVerificationEmail($user, $pdo);
        }
        $sent = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Resend Verification — <?= APP_NAME ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:Arial,sans-serif;background:#f0f4f8;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
  .card{background:#fff;border-radius:16px;box-shadow:0 4px 32px rgba(0,0,0,.1);padding:3rem 2.5rem;max-width:460px;width:100%}
  h1{font-size:1.5rem;font-weight:800;margin-bottom:.5rem;color:#060e1a}
  p{color:#6b7280;line-height:1.7;margin-bottom:1.5rem;font-size:.9rem}
  label{display:block;font-size:.82rem;font-weight:600;margin-bottom:.4rem;color:#374151}
  input{width:100%;padding:.75rem 1rem;border:1px solid #d1d5db;border-radius:8px;font-size:.95rem;outline:none;transition:border .2s}
  input:focus{border-color:#00c471;box-shadow:0 0 0 3px rgba(0,196,113,.15)}
  .btn{display:block;width:100%;background:#00c471;color:#060e1a;padding:.8rem;border:none;border-radius:10px;font-weight:700;font-size:1rem;cursor:pointer;margin-top:1rem;transition:background .2s}
  .btn:hover{background:#009954}
  .alert-success{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534;padding:1rem;border-radius:8px;margin-bottom:1rem;font-size:.9rem}
  .alert-danger{background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:1rem;border-radius:8px;margin-bottom:1rem;font-size:.9rem}
  .back{display:block;text-align:center;margin-top:1.25rem;color:#6b7280;font-size:.85rem;text-decoration:none}
  .back:hover{color:#00c471}
</style>
</head>
<body>
<div class="card">
  <h1>📧 Resend Verification</h1>
  <p>Enter your email address and we'll send you a new verification link.</p>

  <?php if ($sent): ?>
  <div class="alert-success">
    <strong>✅ Check your inbox!</strong><br>
    If that email is registered and unverified, a new link has been sent. Check your spam folder too.
  </div>
  <a href="<?= APP_URL ?>/index.php" class="back">← Back to Login</a>

  <?php else: ?>
  <?php if ($error): ?>
  <div class="alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST">
    <?= csrfField() ?>
    <label for="email">Email Address</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars($email) ?>"
           placeholder="you@email.com" required autofocus>
    <button type="submit" class="btn">Send Verification Link</button>
  </form>
  <a href="<?= APP_URL ?>/index.php" class="back">← Back to Login</a>
  <?php endif; ?>
</div>
</body>
</html>
