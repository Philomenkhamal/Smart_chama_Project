# ChamaLedger — Chama & SACCO Financial Management System

## Default Admin Credentials
> Change these immediately after first login via Settings

| Field    | Value               |
|----------|---------------------|
| Email    | admin@chama.local   |
| Password | Admin@1234          |

## Installation (XAMPP)
1. Extract zip into C:\xampp\htdocs\chama_system\
2. Start Apache and MySQL in XAMPP
3. Open phpMyAdmin: http://localhost/phpmyadmin
4. Create database: chama_db
5. Import: sql/chama_db.sql
6. Edit config/db.php with your DB password
7. Visit: http://localhost/chama_system/
8. If login fails, visit reset_admin.php once then delete it

## Default URLs
- Home:     http://localhost/chama_system/home.php
- Login:    http://localhost/chama_system/index.php
- Register: http://localhost/chama_system/register.php

## Tech Stack
PHP 8+ / MySQL / Bootstrap 5.3 / Chart.js 4.4

Built with ChamaLedger v1.0.0
