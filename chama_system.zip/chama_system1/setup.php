<?php
// ─── PRODUCTION GUARD ─────────────────────────────────────────────────────────
// This file should be DELETED after first use.
// Block access if a SETUP_SECRET env variable is set (production safety).
if (!empty(getenv('DISABLE_SETUP')) || !empty($_ENV['DISABLE_SETUP'])) {
    http_response_code(404);
    die('Not found.');
}
// ──────────────────────────────────────────────────────────────────────────────
/**
 * ChamaLedger — Database Setup Wizard
 * Shown when database tables are missing
 * Auto-imports chama_db.sql and resets admin password
 */
require_once __DIR__ . '/config/db.php';

$step    = 'check';
$errors  = [];
$success = false;

// Test DB connection first
try {
    $pdo = getDB();
    $connected = true;
} catch (Exception $e) {
    $connected = false;
    $errors[]  = 'Cannot connect to database: ' . $e->getMessage();
}

// Check if already set up
$alreadySetup = false;
if ($connected) {
    try {
        $pdo->query("SELECT 1 FROM users LIMIT 1");
        $alreadySetup = true;
    } catch (Exception $e) {
        $alreadySetup = false;
    }
}

// Handle setup action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $connected && !$alreadySetup) {
    try {
        $sqlFile = __DIR__ . '/sql/chama_db.sql';
        if (!file_exists($sqlFile)) throw new Exception('sql/chama_db.sql not found.');

        $sql = file_get_contents($sqlFile);
        // Also ensure newer tables exist (for existing installs upgrading)
        $extraTables = [
            "CREATE TABLE IF NOT EXISTS announcement_replies (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, announcement_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL, message TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_ann (announcement_id)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS otp_tokens (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, otp VARCHAR(10) NOT NULL, purpose ENUM('login','sensitive') NOT NULL DEFAULT 'login', expires_at DATETIME NOT NULL, used TINYINT(1) DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_user (user_id)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS events (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(120) NOT NULL, description TEXT DEFAULT NULL, event_date DATE NOT NULL, target_amount DECIMAL(12,2) DEFAULT NULL, is_mandatory TINYINT(1) NOT NULL DEFAULT 0, status ENUM('active','closed','cancelled') NOT NULL DEFAULT 'active', created_by INT UNSIGNED DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS event_contributions (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL, amount DECIMAL(12,2) NOT NULL, payment_method ENUM('cash','mpesa','bank') NOT NULL DEFAULT 'cash', reference_code VARCHAR(60) DEFAULT NULL, notes TEXT DEFAULT NULL, status ENUM('pending','confirmed','rejected') NOT NULL DEFAULT 'pending', confirmed_by INT UNSIGNED DEFAULT NULL, confirmed_at TIMESTAMP NULL DEFAULT NULL, recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_event (event_id), INDEX idx_user (user_id)) ENGINE=InnoDB",
            "INSERT IGNORE INTO settings (setting_key, setting_value, description) VALUES ('late_fine_enabled','1','Auto-apply late fine when month closes'),('late_fine_amount','500','Amount to fine for late contribution'),('late_fine_grace_days','5','Days after month end before fine is applied')",
            "CREATE TABLE IF NOT EXISTS member_fines (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, fine_type VARCHAR(60) NOT NULL, amount DECIMAL(10,2) NOT NULL, month DATE NOT NULL, description VARCHAR(200) DEFAULT NULL, status ENUM('pending','paid','waived') NOT NULL DEFAULT 'pending', created_by INT UNSIGNED DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_user (user_id), INDEX idx_month (month)) ENGINE=InnoDB",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS nickname VARCHAR(60) DEFAULT NULL",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS chama_position VARCHAR(80) DEFAULT NULL",
            "CREATE TABLE IF NOT EXISTS member_wallet (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL UNIQUE, balance DECIMAL(12,2) NOT NULL DEFAULT 0.00, last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS wallet_ledger (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, type ENUM('credit','debit') NOT NULL, amount DECIMAL(12,2) NOT NULL, balance_after DECIMAL(12,2) NOT NULL, description VARCHAR(255) NOT NULL, ref_type VARCHAR(40) DEFAULT NULL, ref_id INT UNSIGNED DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_user (user_id)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS ai_insights (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, type VARCHAR(60) NOT NULL, payload JSON NOT NULL, generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_type (type)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS mpesa_verifications (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, receipt_code VARCHAR(20) NOT NULL, context VARCHAR(30) DEFAULT 'contribution', context_id INT UNSIGNED DEFAULT NULL, status ENUM('pending','verified','failed') DEFAULT 'pending', result_data TEXT DEFAULT NULL, checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE KEY uq_receipt (receipt_code)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS dividends (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, year YEAR NOT NULL, total_profit DECIMAL(14,2) NOT NULL DEFAULT 0, total_savings DECIMAL(14,2) NOT NULL DEFAULT 0, notes TEXT DEFAULT NULL, status ENUM('draft','distributed') NOT NULL DEFAULT 'draft', created_by INT UNSIGNED DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, distributed_at TIMESTAMP NULL DEFAULT NULL, UNIQUE KEY uq_year (year)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS dividend_shares (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, dividend_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL, avg_balance DECIMAL(14,2) NOT NULL DEFAULT 0, share_pct DECIMAL(8,4) NOT NULL DEFAULT 0, share_amount DECIMAL(14,2) NOT NULL DEFAULT 0, notified TINYINT(1) DEFAULT 0, FOREIGN KEY (dividend_id) REFERENCES dividends(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, UNIQUE KEY uq_div_user (dividend_id, user_id)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS sms_log (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED DEFAULT NULL, phone VARCHAR(20) NOT NULL, message TEXT NOT NULL, type VARCHAR(50) DEFAULT 'general', status VARCHAR(20) DEFAULT 'sent', sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB",
        ];

        // Split into individual statements
        $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
        $statements = array_filter(
            array_merge(array_map('trim', explode(';', $sql)), $extraTables),
            fn($s) => strlen($s) > 5
        );

        foreach ($statements as $stmt) {
            if (trim($stmt)) $pdo->exec($stmt);
        }
        $pdo->exec("SET FOREIGN_KEY_CHECKS=1");

        // ── Column migrations (safe to run every time) ──────────────────────────
        $migrations = [
            "ALTER TABLE mpesa_transactions ADD COLUMN IF NOT EXISTS event_id INT UNSIGNED DEFAULT NULL AFTER contribution_id",
            "ALTER TABLE mpesa_transactions ADD COLUMN IF NOT EXISTS loan_id  INT UNSIGNED DEFAULT NULL AFTER event_id",
        ];
        foreach ($migrations as $mig) {
            try { $pdo->exec($mig); } catch(PDOException $e) { /* column exists */ }
        }

        // Generate fresh admin password hash using THIS PHP version
        $hash = password_hash('Admin@1234', PASSWORD_BCRYPT, ['cost' => 10]);
        $pdo->prepare("UPDATE users SET password_hash=? WHERE role='admin'")->execute([$hash]);

        $success = true;

    } catch (Exception $e) {
        $errors[] = 'Setup failed: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup — ChamaLedger</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'DM Sans',sans-serif;background:#060e1a;color:#e2eaf4;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1.5rem}
        .card{background:#0d1f38;border:1px solid rgba(255,255,255,0.07);border-radius:18px;padding:2.5rem;max-width:520px;width:100%;box-shadow:0 12px 48px rgba(0,0,0,0.5)}
        .logo{display:flex;align-items:center;gap:.75rem;margin-bottom:2rem}
        .logo-icon{width:42px;height:42px;background:linear-gradient(135deg,#00c471,#009954);border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:#fff;box-shadow:0 0 20px rgba(0,196,113,0.3)}
        .logo-text{font-family:'Syne',sans-serif;font-weight:800;font-size:1.3rem;color:#fff}
        .logo-text span{color:#00c471}
        h2{font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:800;margin-bottom:.4rem}
        .subtitle{font-size:.875rem;color:#6b87a8;margin-bottom:2rem;line-height:1.6}

        .check-item{display:flex;align-items:center;gap:.75rem;padding:.7rem 1rem;border-radius:10px;margin-bottom:.5rem;font-size:.875rem}
        .check-item.ok  {background:rgba(0,196,113,0.08);border:1px solid rgba(0,196,113,0.15);color:#6ee7b7}
        .check-item.err {background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.15);color:#fca5a5}
        .check-item.warn{background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.15);color:#fcd34d}
        .check-item i{font-size:1.1rem;flex-shrink:0}

        .creds-box{background:rgba(0,196,113,0.07);border:1px solid rgba(0,196,113,0.2);border-radius:12px;padding:1.25rem;margin:1.25rem 0}
        .creds-box .label{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b87a8;margin-bottom:.2rem}
        .creds-box .value{font-family:monospace;font-size:1rem;font-weight:700;color:#00c471}

        .btn{display:block;width:100%;padding:.9rem;background:#00c471;color:#060e1a;border:none;border-radius:10px;font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;cursor:pointer;text-align:center;text-decoration:none;transition:all .2s;margin-top:1.5rem}
        .btn:hover{background:#00dc7e;transform:translateY(-1px);box-shadow:0 8px 30px rgba(0,196,113,0.4);color:#060e1a}
        .btn.secondary{background:rgba(255,255,255,0.07);color:#e2eaf4;border:1px solid rgba(255,255,255,0.1)}
        .btn.secondary:hover{background:rgba(255,255,255,0.12)}
        .btn:disabled{opacity:.6;cursor:not-allowed;transform:none}

        .error-box{background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.2);border-radius:10px;padding:1rem;margin-bottom:1rem;font-size:.875rem;color:#fca5a5}
        .step-badge{display:inline-block;background:rgba(0,196,113,0.12);color:#00c471;border:1px solid rgba(0,196,113,0.2);border-radius:99px;font-size:.7rem;font-weight:700;padding:.2rem .75rem;text-transform:uppercase;letter-spacing:.06em;margin-bottom:1rem}
        .divider{height:1px;background:rgba(255,255,255,0.07);margin:1.5rem 0}

        .spinner{display:inline-block;width:18px;height:18px;border:2px solid #060e1a;border-top-color:transparent;border-radius:50%;animation:spin .6s linear infinite;vertical-align:middle;margin-right:.4rem}
        @keyframes spin{to{transform:rotate(360deg)}}
    </style>
</head>
<body>
<div class="card">
    <div class="logo">
        <div class="logo-icon"><i class="bi bi-bank2"></i></div>
        <span class="logo-text">Chama<span>Ledger</span></span>
    </div>

    <?php if ($alreadySetup): ?>
    <!-- Already installed -->
    <div class="step-badge">✅ Already Installed</div>
    <h2>System is ready</h2>
    <p class="subtitle">ChamaLedger is already installed and your database is set up correctly.</p>
    <div class="check-item ok"><i class="bi bi-check-circle-fill"></i> Database connected and tables exist</div>
    <a href="<?= APP_URL ?>/index.php" class="btn">Go to Login →</a>

    <?php elseif ($success): ?>
    <!-- Setup complete -->
    <div class="step-badge">🎉 Setup Complete</div>
    <h2>Installation successful!</h2>
    <p class="subtitle">Your database has been set up and the admin account is ready.</p>

    <div class="check-item ok"><i class="bi bi-check-circle-fill"></i> All database tables created</div>
    <div class="check-item ok"><i class="bi bi-check-circle-fill"></i> Admin password set using your PHP version</div>

    <div class="creds-box">
        <div class="label">Admin Email</div>
        <div class="value">admin@chama.local</div>
        <div style="margin-top:.75rem" class="label">Admin Password</div>
        <div class="value">Admin@1234</div>
        <div style="margin-top:.75rem;font-size:.75rem;color:#6b87a8">⚠️ Change this password after your first login.</div>
    </div>

    <a href="<?= APP_URL ?>/index.php" class="btn">Go to Login →</a>

    <?php elseif (!$connected): ?>
    <!-- DB connection failed -->
    <div class="step-badge">❌ Connection Error</div>
    <h2>Cannot connect to database</h2>
    <p class="subtitle">ChamaLedger cannot connect to MySQL. Please check your settings in <code>config/db.php</code>.</p>

    <?php foreach ($errors as $e): ?>
    <div class="error-box"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($e) ?></div>
    <?php endforeach; ?>

    <div class="divider"></div>
    <div style="font-size:.82rem;color:#6b87a8;line-height:1.8">
        <strong style="color:#e2eaf4">How to fix:</strong><br>
        1. Open XAMPP Control Panel — start <strong>Apache</strong> and <strong>MySQL</strong><br>
        2. Open <code>config/db.php</code><br>
        3. Set <code>DB_USER</code> to <code>root</code> and <code>DB_PASS</code> to your MySQL password (usually empty on XAMPP)<br>
        4. Reload this page
    </div>
    <a href="<?= APP_URL ?>/setup.php" class="btn secondary" onclick="location.reload();return false;">↻ Retry Connection</a>

    <?php else: ?>
    <!-- Ready to install -->
    <div class="step-badge">⚙️ First Time Setup</div>
    <h2>Install ChamaLedger</h2>
    <p class="subtitle">Database is connected but tables are missing. Click below to automatically create all tables and set up the admin account.</p>

    <div class="check-item ok"><i class="bi bi-check-circle-fill"></i> MySQL connected — database: <strong><?= DB_NAME ?></strong></div>
    <div class="check-item warn"><i class="bi bi-exclamation-triangle-fill"></i> Tables not found — need to run setup</div>

    <?php if (!empty($errors)): ?>
    <?php foreach ($errors as $e): ?>
    <div class="error-box"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($e) ?></div>
    <?php endforeach; ?>
    <?php endif; ?>

    <div class="divider"></div>
    <div style="font-size:.82rem;color:#6b87a8;line-height:1.8;margin-bottom:1rem">
        This will:<br>
        ✓ Create all <?= DB_NAME ?> tables automatically<br>
        ✓ Insert default system settings<br>
        ✓ Create admin account (<code>admin@chama.local</code> / <code>Admin@1234</code>)<br>
        ✓ Generate a password hash using <strong>your PHP version (<?= PHP_VERSION ?>)</strong>
    </div>

    <form method="POST">
        <button type="submit" class="btn" id="setupBtn" onclick="this.disabled=true;this.innerHTML='<span class=spinner></span> Installing…';this.closest('form').submit()">
            <i class="bi bi-download me-1"></i> Run Setup Now
        </button>
    </form>

    <?php endif; ?>
</div>
</body>
</html>
