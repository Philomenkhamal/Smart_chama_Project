<?php
// Bypass ngrok browser warning
@header('ngrok-skip-browser-warning: true');
if (!defined('ROOT')) define('ROOT', __DIR__);
require_once ROOT . '/includes/functions.php';
require_once ROOT . '/includes/mailer.php';
if (!dbIsReady()) { header('Location: ' . APP_URL . '/setup.php'); exit; }
startSession();

// Must have pending_2fa in session
if (empty($_SESSION['pending_2fa_user_id'])) {
    header('Location: ' . APP_URL . '/index.php'); exit;
}

$pdo     = getDB();
$userId  = (int)$_SESSION['pending_2fa_user_id'];
$errors  = [];
$resent  = false;

$user = $pdo->prepare("SELECT * FROM users WHERE id=? AND status='active'");
$user->execute([$userId]); $user = $user->fetch();
if (!$user) { session_destroy(); header('Location: ' . APP_URL . '/index.php'); exit; }

// Generate and send OTP
function sendOtp(array $user, object $pdo): string {
    $otp     = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expires = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    $pdo->prepare("DELETE FROM otp_tokens WHERE user_id=? AND purpose='login'")->execute([$user['id']]);
    $pdo->prepare("INSERT INTO otp_tokens (user_id, otp, purpose, expires_at) VALUES (?,?,?,?)")
        ->execute([$user['id'], password_hash($otp, PASSWORD_BCRYPT), 'login', $expires]);
    // Send via email
    $mailer = new Mailer();
    $mailer->send($user['email'], $user['full_name'], '🔐 Your ChamaLedger Login Code',
        (new Mailer())->send($user['email'], '', '', '') ? '' :
        (function() use ($user, $otp) {
            return <<<HTML
<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;background:#f0f4f8;padding:2rem">

<!-- Language Toggle -->
<div style="position:fixed;top:16px;right:20px;z-index:9999;display:flex;gap:6px;">
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=en"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='en' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='en' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇬🇧 EN
  </a>
  <a href="<?= (defined('APP_URL') ? APP_URL : '') ?>/api/set_lang.php?lang=sw"
     style="text-decoration:none;font-size:12px;font-weight:700;padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.3);color:<?= getLang()==='sw' ? '#fff' : 'rgba(255,255,255,0.6)' ?>;background:<?= getLang()==='sw' ? 'rgba(255,255,255,0.2)' : 'transparent' ?>;">
    🇰🇪 SW
  </a>
</div>

<div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden">
  <div style="background:#060e1a;padding:1.5rem;text-align:center">
    <span style="font-size:1.2rem;font-weight:800;color:#fff">🏦 ChamaLedger</span>
  </div>
  <div style="padding:2rem;text-align:center">
    <div style="font-size:2.5rem;margin-bottom:1rem">🔐</div>
    <h2 style="color:#1a2940;margin-bottom:.5rem"><?= t('otp_your_code') ?></h2>
    <p style="color:#6b87a8;font-size:.88rem;margin-bottom:1.5rem">Hi {$user['full_name']}, use this code to complete your sign in:</p>
    <div style="background:#f0fdf4;border:2px solid #00c471;border-radius:12px;padding:1.25rem;margin:0 auto;max-width:200px">
      <div style="font-size:2.2rem;font-weight:900;letter-spacing:.3em;color:#047857;font-family:monospace">{$otp}</div>
    </div>
    <p style="color:#9ca3af;font-size:.78rem;margin-top:1.25rem"><?= t('otp_expires_hint') ?></p>
  </div>
</div></body></html>
HTML;
        })()
    );
    // Send the actual email properly
    $html = <<<HTML
<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;background:#f0f4f8;padding:2rem">
<div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden">
  <div style="background:#060e1a;padding:1.5rem;text-align:center"><span style="font-size:1.2rem;font-weight:800;color:#fff">🏦 ChamaLedger</span></div>
  <div style="padding:2rem;text-align:center">
    <div style="font-size:2.5rem;margin-bottom:1rem">🔐</div>
    <h2 style="color:#1a2940;margin-bottom:.5rem"><?= t('otp_your_code') ?></h2>
    <p style="color:#6b87a8;font-size:.88rem;margin-bottom:1.5rem">Hi {$user['full_name']}, use this code to complete your sign in. It expires in <strong>10 minutes</strong>.</p>
    <div style="background:#f0fdf4;border:2px solid #00c471;border-radius:12px;padding:1.25rem;margin:0 auto;max-width:220px">
      <div style="font-size:2.4rem;font-weight:900;letter-spacing:.35em;color:#047857;font-family:monospace">{$otp}</div>
    </div>
    <p style="color:#9ca3af;font-size:.78rem;margin-top:1.25rem"><?= t('otp_share_warning') ?></p>
  </div>
</div></body></html>
HTML;
    $mailer->send($user['email'], $user['full_name'], '🔐 Your ChamaLedger Login Code — ' . $otp, $html);
    return $otp; // return for dev/debug display
}

// Send on first load
if (!isset($_SESSION['otp_sent_at'])) {
    sendOtp($user, $pdo);
    $_SESSION['otp_sent_at'] = time();
}

// Resend
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resend'])) {
    if (time() - ($_SESSION['otp_sent_at'] ?? 0) > 30) {
        sendOtp($user, $pdo);
        $_SESSION['otp_sent_at'] = time();
        $resent = true;
    } else {
        $errors[] = t('otp_wait_resend');
    }
}

// Verify
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp']) && verifyCsrf($_POST['csrf_token'] ?? '')) {
    $input = preg_replace('/\s+/', '', $_POST['otp'] ?? '');

    // ── Brute-force guard ────────────────────────────────────────────────────
    $_SESSION['otp_attempts'] = ($_SESSION['otp_attempts'] ?? 0);
    $_SESSION['otp_locked_until'] = ($_SESSION['otp_locked_until'] ?? 0);

    if (time() < $_SESSION['otp_locked_until']) {
        $wait = ceil(($_SESSION['otp_locked_until'] - time()) / 60);
        $errors[] = "sprintf(t('otp_locked_wait'), \$wait)";
    } else {
        $token = $pdo->prepare("SELECT * FROM otp_tokens WHERE user_id=? AND purpose='login' AND used=0 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
        $token->execute([$userId]); $token = $token->fetch();

        if (!$token || !password_verify($input, $token['otp'])) {
            $_SESSION['otp_attempts']++;
            if ($_SESSION['otp_attempts'] >= 5) {
                $_SESSION['otp_locked_until'] = time() + 900; // 15-minute lockout
                $_SESSION['otp_attempts'] = 0;
                logActivity('OTP_LOCKED', 'OTP brute-force lockout triggered', $userId);
                $errors[] = 'Too many failed attempts. Your session has been locked for 15 minutes.';
            } else {
                $remaining = 5 - $_SESSION['otp_attempts'];
                $errors[] = "sprintf(t('otp_invalid_remaining'), \$remaining)";
            }
        } else {
            // Success — reset counters, mark token used, complete login
            $_SESSION['otp_attempts']    = 0;
            $_SESSION['otp_locked_until'] = 0;
            $pdo->prepare("UPDATE otp_tokens SET used=1 WHERE id=?")->execute([$token['id']]);
            unset($_SESSION['pending_2fa_user_id'], $_SESSION['otp_sent_at']);
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['role']      = $user['role'];
            logActivity('LOGIN_2FA', '2FA login success', $user['id']);
            $dest = $user['role'] === 'admin' ? APP_URL . '/admin/dashboard.php' : APP_URL . '/member/dashboard.php';
            header('Location: ' . $dest); exit;
        }
    }
}

$maskedEmail = preg_replace('/(?<=.{2}).(?=.*@)/u', '*', $user['email']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= t('otp_title') ?> — <?= APP_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
    :root{--green:#00c471;--green-dark:#009954;--green-glow:rgba(0,196,113,.2);--navy:#050f1c;--text:#e8f0f8;--muted:#7a94b0;--border:rgba(0,196,113,.18);--input-bg:rgba(15,45,74,.6)}
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}html,body{height:100%}
    body{font-family:'DM Sans',sans-serif;background:var(--navy);color:var(--text);display:flex;min-height:100vh}
    .left-panel{flex:0 0 45%;background:linear-gradient(160deg,#071628,#0a2240 50%,#061320);display:flex;flex-direction:column;justify-content:space-between;padding:3rem;position:relative;overflow:hidden}
    .left-panel::before{content:'';position:absolute;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(0,196,113,.15),transparent 65%);top:-100px;right:-150px;animation:glow 8s ease-in-out infinite}
    @keyframes glow{0%,100%{transform:scale(1) translate(0,0)}50%{transform:scale(1.15) translate(20px,-15px)}}
    .panel-logo{display:flex;align-items:center;gap:.75rem;text-decoration:none;z-index:1;position:relative}
    .panel-logo-icon{width:44px;height:44px;background:linear-gradient(135deg,var(--green),var(--green-dark));border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#fff;box-shadow:0 0 24px var(--green-glow)}
    .panel-logo-text{font-family:'Syne',sans-serif;font-weight:800;font-size:1.4rem;color:#fff;letter-spacing:-.02em}
    .panel-logo-text span{color:var(--green)}
    .panel-content{position:relative;z-index:1;animation:fadeUp .6s ease .2s both}
    .panel-tagline{font-family:'Syne',sans-serif;font-size:clamp(1.9rem,3.5vw,2.8rem);font-weight:800;line-height:1.1;letter-spacing:-.03em;margin-bottom:1.2rem}
    .panel-tagline .accent{color:var(--green)}
    .panel-sub{font-size:.95rem;color:var(--muted);line-height:1.7;max-width:340px;margin-bottom:2.5rem}
    .panel-features{display:flex;flex-direction:column;gap:.9rem}
    .panel-feature{display:flex;align-items:center;gap:.75rem;font-size:.88rem;color:rgba(232,240,248,.75)}
    .panel-feature-dot{width:28px;height:28px;border-radius:8px;background:var(--green-glow);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:.85rem;color:var(--green);flex-shrink:0}
    .panel-footer{position:relative;z-index:1;font-size:.75rem;color:var(--muted)}
    .right-panel{flex:1;display:flex;align-items:center;justify-content:center;padding:2rem;position:relative;background:var(--navy)}
    .right-panel::before{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(0,196,113,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,196,113,.04) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}
    .form-box{width:100%;max-width:420px;position:relative;z-index:1;animation:fadeUp .6s ease .1s both}
    .form-header{margin-bottom:2rem}
    .form-header h1{font-family:'Syne',sans-serif;font-size:1.9rem;font-weight:800;letter-spacing:-.02em;margin-bottom:.35rem}
    .form-header p{font-size:.9rem;color:var(--muted)}
    .alert-box{padding:.85rem 1rem;border-radius:10px;font-size:.875rem;margin-bottom:1.25rem;display:flex;align-items:flex-start;gap:.6rem;animation:shake .4s ease}
    .alert-danger{background:rgba(220,53,69,.12);border:1px solid rgba(220,53,69,.3);color:#ff8b96}
    .alert-success{background:rgba(0,196,113,.12);border:1px solid rgba(0,196,113,.3);color:var(--green)}
    @keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-6px)}40%,80%{transform:translateX(6px)}}
    /* OTP input boxes */
    .otp-wrap{display:flex;gap:.65rem;justify-content:center;margin-bottom:1.5rem}
    .otp-input{width:52px;height:60px;background:var(--input-bg);border:1px solid rgba(255,255,255,.08);border-radius:12px;text-align:center;font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:var(--text);outline:none;transition:all .2s;caret-color:var(--green)}
    .otp-input:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow);background:rgba(15,45,74,.8)}
    .otp-input.filled{border-color:rgba(0,196,113,.4);background:rgba(0,196,113,.06)}
    .btn-submit{width:100%;padding:.9rem;background:var(--green);color:#050f1c;border:none;border-radius:10px;font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;cursor:pointer;transition:all .25s;box-shadow:0 4px 30px rgba(0,196,113,.3);display:flex;align-items:center;justify-content:center;gap:.5rem}
    .btn-submit:hover{background:#00dc7e;transform:translateY(-2px)}
    .btn-submit:disabled{opacity:.6;cursor:not-allowed;transform:none}
    .divider{display:flex;align-items:center;gap:1rem;margin:1.25rem 0;font-size:.78rem;color:var(--muted)}
    .divider::before,.divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.07)}
    .back-link{display:flex;align-items:center;justify-content:center;gap:.4rem;font-size:.85rem;color:var(--muted);text-decoration:none;transition:color .2s}
    .back-link:hover{color:var(--green)}
    .resend-btn{background:none;border:none;color:var(--green);font-weight:600;cursor:pointer;font-size:.85rem;padding:0;transition:opacity .2s}
    .resend-btn:disabled{opacity:.4;cursor:not-allowed}
    @keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}
    @media(max-width:768px){.left-panel{display:none}.right-panel{padding:1.5rem 1.25rem}}
</style>
</head>
<body>
<div class="left-panel">
    <a href="<?= APP_URL ?>/home.php" class="panel-logo">
        <div class="panel-logo-icon"><i class="bi bi-bank2"></i></div>
        <span class="panel-logo-text"><?= APP_NAME ?></span>
    </a>
    <div class="panel-content">
        <h2 class="panel-tagline"><?= t('otp_panel_title') ?></h2>
        <p class="panel-sub"><?= t('otp_panel_sub') ?></p>
        <div class="panel-features">
            <div class="panel-feature"><div class="panel-feature-dot"><i class="bi bi-shield-lock"></i></div><?= t('otp_feat1') ?></div>
            <div class="panel-feature"><div class="panel-feature-dot"><i class="bi bi-clock"></i></div><?= t('otp_feat2') ?></div>
            <div class="panel-feature"><div class="panel-feature-dot"><i class="bi bi-envelope-check"></i></div><?= t('otp_feat3') ?></div>
        </div>
    </div>
    <div class="panel-footer">© <?= date('Y') ?> ChamaLedger</div>
</div>
<div class="right-panel">
    <div class="form-box">
        <div class="form-header">
            <h1><?= t('otp_heading') ?></h1>
            <p><?= t('otp_sub') ?> <strong style="color:var(--text)"><?= htmlspecialchars($maskedEmail) ?></strong></p>
        </div>

        <?php if (!empty($errors)): ?>
        <div class="alert-box alert-danger">
            <i class="bi bi-exclamation-triangle-fill" style="flex-shrink:0;margin-top:2px"></i>
            <div><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
        </div>
        <?php elseif ($resent): ?>
        <div class="alert-box alert-success">
            <i class="bi bi-check-circle-fill" style="flex-shrink:0"></i>
            <?= t('otp_new_sent') ?>
        </div>
        <?php endif; ?>

        <form method="POST" id="otpForm">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="otp" id="otpHidden">

            <div class="otp-wrap">
                <?php for ($i = 1; $i <= 6; $i++): ?>
                <input type="text" class="otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" id="otp<?= $i ?>" autocomplete="off">
                <?php endfor; ?>
            </div>

            <button type="submit" class="btn-submit" id="verifyBtn" disabled>
                <i class="bi bi-shield-check"></i> <?= t('otp_verify_btn') ?>
            </button>
        </form>

        <div class="divider"><?= t('otp_no_code') ?></div>

        <div style="text-align:center">
            <form method="POST" style="display:inline">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="resend" value="1">
                <button type="submit" class="resend-btn" id="resendBtn">
                    <?= t('otp_resend') ?>
                </button>
            </form>
            <span style="color:var(--muted);font-size:.85rem" id="resendTimer"></span>
        </div>

        <div class="divider">or</div>
        <a href="<?= APP_URL ?>/index.php" class="back-link" onclick="<?php session_unset(); ?>">
            <i class="bi bi-arrow-left"></i> <?= t('otp_back_signin') ?>
        </a>
    </div>
</div>

<script>
var inputs = document.querySelectorAll('.otp-input');
var hidden  = document.getElementById('otpHidden');
var btn     = document.getElementById('verifyBtn');

// Auto-advance between boxes
inputs.forEach(function(input, i) {
    input.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g,'');
        if (this.value) {
            this.classList.add('filled');
            if (i < inputs.length - 1) inputs[i+1].focus();
        } else {
            this.classList.remove('filled');
        }
        updateHidden();
    });
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Backspace' && !this.value && i > 0) {
            inputs[i-1].focus();
            inputs[i-1].value = '';
            inputs[i-1].classList.remove('filled');
            updateHidden();
        }
    });
    input.addEventListener('paste', function(e) {
        e.preventDefault();
        var paste = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g,'').slice(0,6);
        paste.split('').forEach(function(ch, j) {
            if (inputs[j]) { inputs[j].value = ch; inputs[j].classList.add('filled'); }
        });
        if (inputs[Math.min(paste.length, 5)]) inputs[Math.min(paste.length, 5)].focus();
        updateHidden();
    });
});

function updateHidden() {
    var val = Array.from(inputs).map(function(i){ return i.value; }).join('');
    hidden.value = val;
    btn.disabled = val.length < 6;
    if (val.length === 6) { btn.style.background = '#00c471'; }
}

// Auto-submit when all 6 filled
function checkAutoSubmit() {
    var val = Array.from(inputs).map(function(i){ return i.value; }).join('');
    if (val.length === 6) {
        setTimeout(function() { document.getElementById('otpForm').submit(); }, 300);
    }
}
inputs[5].addEventListener('input', checkAutoSubmit);

// Resend cooldown timer
var resendBtn   = document.getElementById('resendBtn');
var resendTimer = document.getElementById('resendTimer');
var cooldown    = <?= max(0, 30 - (time() - ($_SESSION['otp_sent_at'] ?? time()))) ?>;

function startCooldown(secs) {
    resendBtn.disabled = true;
    var t = setInterval(function() {
        secs--;
        resendTimer.textContent = secs > 0 ? '(' + secs + 's)' : '';
        if (secs <= 0) { clearInterval(t); resendBtn.disabled = false; }
    }, 1000);
}
if (cooldown > 0) startCooldown(cooldown);

// Auto-dismiss alerts
document.querySelectorAll('.alert-box').forEach(function(a) {
    setTimeout(function() { a.style.transition='opacity .5s'; a.style.opacity='0'; setTimeout(function(){a.remove();},500); }, 4000);
});

inputs[0].focus();
</script>
</body>
</html>
